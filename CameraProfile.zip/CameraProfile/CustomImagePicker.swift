//
//  CustomImagePicker.swift
//  CameraProfile
//
//  Created by Abhay on 24/12/19.
//  Copyright © 2019 Abhay. All rights reserved.
//

import UIKit
import Photos





class CustomImagePicker:UIViewController,UICollectionViewDelegate,UICollectionViewDataSource{
  
    @IBOutlet weak var collectionview: UICollectionView!

    var assets = PHFetchResult<PHAsset>()
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
        collectionview.delegate = self
        collectionview.dataSource = self
        
        assets = PHAsset.fetchAssets(with: PHAssetMediaType.image, options: nil)
                   
        
        
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return assets.count
          }
          
          func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
              
            let cell = self.collectionview.dequeueReusableCell(withReuseIdentifier: "VideoCell", for: indexPath) as! ImagePickerCell
              
              
            
            
            let manager = PHImageManager.default()
          
            var thumbnail = UIImage()
            manager.requestImage(for: assets[indexPath.row], targetSize: CGSize(width: 100   , height: 100), contentMode: .aspectFill, options: nil, resultHandler: {(result, info)->Void in
                thumbnail = result!
            })
            cell.thumbnail.image = thumbnail
            
            
          return cell
    }
   
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
           // handle tap events
           print("You selected cell #\(indexPath.item)!")
       }
    
   
    
    
}
